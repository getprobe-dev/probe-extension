var _=(function(j){"use strict";function P(e,n){return e.then(n).catch(t=>{n({ok:!1,error:t instanceof Error?t.message:"Unknown error"})}),!0}function R(e,n){try{e.postMessage(n)}catch{}}const fe="https://probe-proxy.sgunturi.workers.dev",he={anthropic:"claude-opus-4-6",openai:"gpt-5.4"},w={API_KEY:"llm_api_key",LLM_PROVIDER:"llm_provider",MODEL_NAME:"llm_model_name",PROXY_URL:"proxy_url",GITHUB_TOKEN:"github_token"},me="2022-11-28",k=100,U="No GitHub token configured. Click the PRobe extension icon to add one.";function E(e,n){return`https://api.github.com/repos/${e}/${n}`}async function pe(){return new Promise(e=>{chrome.storage.sync.get([w.GITHUB_TOKEN],n=>{e(n[w.GITHUB_TOKEN]??null)})})}async function C(){const e=await pe();return e?{Authorization:`Bearer ${e}`,Accept:"application/vnd.github+json","Content-Type":"application/json","X-GitHub-Api-Version":me}:null}async function F(e){let n=`GitHub API error (${e.status})`;try{const t=JSON.parse(await e.text()),o=t?.message,i=t?.errors;if(i?.length){const s=i.map(c=>c&&typeof c=="object"&&"message"in c?c.message:null).filter(Boolean);n=s.length?s.join("; "):o??n}else n=o??n}catch{console.warn("[PRobe] Failed to parse GitHub API error body")}return n}async function ye(e){const n=await C();if(!n)return{ok:!1,error:U};const t=`${E(e.owner,e.repo)}/issues/${e.number}/comments`,o=await fetch(t,{method:"POST",headers:n,body:JSON.stringify({body:e.body})});return o.ok?{ok:!0,url:(await o.json()).html_url}:{ok:!1,error:await F(o)}}async function ge(e){const n=await C();if(!n)return{ok:!1,error:U};const t=`${E(e.owner,e.repo)}/pulls/${e.number}/reviews`,o=await fetch(t,{method:"POST",headers:n,body:JSON.stringify({event:"COMMENT",comments:[{path:e.path,body:e.body,line:e.line,side:e.side}]})});return o.ok?{ok:!0,url:(await o.json()).html_url}:{ok:!1,error:await F(o)}}async function be(e){const n=await C();if(!n)return{ok:!1,error:U};const t=e.body||(e.event==="REQUEST_CHANGES"?"Changes requested.":void 0),o=`${E(e.owner,e.repo)}/pulls/${e.number}/reviews`,i=await fetch(o,{method:"POST",headers:n,body:JSON.stringify({body:t,event:e.event,comments:e.comments.map(c=>({path:c.path,body:c.body,line:c.line,side:c.side}))})});return i.ok?{ok:!0,url:(await i.json()).html_url}:{ok:!1,error:await F(i)}}const we=4e5,Q=3e4,ve=/(?:closes|fixes|resolves|part of|related:?)\s+#(\d+)/gi,$e=5;async function ke(e,n){const t=await C();if(n.aborted)return{ok:!1,error:"Cancelled"};const o=E(e.owner,e.repo),i=`https://github.com/${e.owner}/${e.repo}/pull/${e.number}.diff`,s={diff:fetch(i,{signal:n}),pr:t?fetch(`${o}/pulls/${e.number}`,{headers:t,signal:n}):Promise.reject("no token"),commits:t?fetch(`${o}/pulls/${e.number}/commits?per_page=${k}`,{headers:t,signal:n}):Promise.reject("no token"),reviews:t?fetch(`${o}/pulls/${e.number}/reviews?per_page=${k}`,{headers:t,signal:n}):Promise.reject("no token"),issueComments:t?fetch(`${o}/issues/${e.number}/comments?per_page=${k}`,{headers:t,signal:n}):Promise.reject("no token"),reviewComments:t?fetch(`${o}/pulls/${e.number}/comments?per_page=${k}`,{headers:t,signal:n}):Promise.reject("no token"),files:t?fetch(`${o}/pulls/${e.number}/files?per_page=${k}`,{headers:t,signal:n}):Promise.reject("no token")},c=await Promise.allSettled(Object.values(s)),l=Object.keys(s),u={};for(let r=0;r<l.length;r++){const p=c[r];u[l[r]]=p.status==="fulfilled"&&p.value.ok?p.value:null}const f=u.diff?await u.diff.text():"";if(!f)return{ok:!1,error:"Failed to fetch PR diff"};const a=u.pr?await u.pr.json():null,m=a?.title??`PR #${e.number}`,y=a?.body??"",v=a?.user?.login??"",h=a?.base?.ref??"main",O=a?.head?.ref??"",d=a?.head?.sha??"",b=(u.commits?await u.commits.json():[]).map(r=>({sha:r.sha.slice(0,7),message:r.commit.message.split(`
`)[0],author:r.author?.login??r.commit.author?.name??"unknown",date:r.commit.author?.date??""})),D=u.reviews?await u.reviews.json():[],I=new Map;for(const r of D)r.user?.login&&I.set(r.user.login,{author:r.user.login,state:r.state,body:r.body??""});const L=Array.from(I.values()),M=u.issueComments?await u.issueComments.json():[],B=u.reviewComments?await u.reviewComments.json():[],N=[...M.map(r=>({author:r.user?.login??"unknown",body:r.body,createdAt:r.created_at})),...B.map(r=>({author:r.user?.login??"unknown",body:r.body,path:r.path,line:r.line??void 0,createdAt:r.created_at}))];N.sort((r,p)=>new Date(p.createdAt).getTime()-new Date(r.createdAt).getTime());const ut=N.slice(0,$e),W=(u.files?await u.files.json():[]).map(r=>({filename:r.filename,status:r.status,additions:r.additions,deletions:r.deletions}));let ue=[];if(t&&d&&!n.aborted)try{const r=await fetch(`${o}/commits/${d}/check-runs?per_page=${k}`,{headers:t,signal:n});r.ok&&(ue=(await r.json()).check_runs.map(S=>({name:S.name,status:S.status,conclusion:S.conclusion})))}catch{console.warn("[PRobe] Checks endpoint unavailable")}const de=[];if(t&&y&&!n.aborted){const r=new Set;let p;for(;(p=ve.exec(y))!==null;)r.add(parseInt(p[1],10));const S=await Promise.allSettled([...r].map(async $=>{const A=await fetch(`${o}/issues/${$}`,{headers:t,signal:n});if(!A.ok)return null;const z=await A.json();return{number:z.number,title:z.title,body:z.body??""}}));for(const $ of S)$.status==="fulfilled"&&$.value&&de.push($.value)}const dt=!t||!a&&b.length===0&&L.length===0&&W.length===0,X=[...W].filter(r=>r.status!=="removed").sort((r,p)=>p.additions+p.deletions-(r.additions+r.deletions)),ft=`https://raw.githubusercontent.com/${e.owner}/${e.repo}/${d}`,J={};let V=we;if(d&&!n.aborted){const r=await Promise.allSettled(X.map(p=>fetch(`${ft}/${p.filename}`,{signal:n})));for(let p=0;p<X.length&&!(V<=0);p++){const S=r[p];if(S.status!=="fulfilled"||!S.value.ok)continue;const $=await S.value.text();if($.slice(0,1024).includes("\0"))continue;const A=$.length>Q?$.slice(0,Q)+`
… [truncated]`:$;if(A.length>V)break;J[X[p].filename]=A,V-=A.length}}return{ok:!0,context:{owner:e.owner,repo:e.repo,number:e.number,title:m,description:y,diff:f,headBranch:O,baseBranch:h,author:v,state:a?.state??"open",draft:a?.draft??!1,mergeable:a?.mergeable??null,mergeableState:a?.mergeable_state??"unknown",labels:(a?.labels??[]).map(r=>r.name),milestone:a?.milestone?.title??"",assignees:(a?.assignees??[]).map(r=>r.login),requestedReviewers:(a?.requested_reviewers??[]).map(r=>r.login),commits:b,reviews:L,recentComments:ut,checks:ue,files:W,linkedIssues:de,fileContents:Object.keys(J).length>0?J:void 0,...dt?{partial:!0}:{}}}}const Ie=30;async function Se(e){const n=await C();if(!n)return{ok:!1,error:"No GitHub token configured."};const t=`${E(e.owner,e.repo)}/pulls/${e.number}`,[o,i,s,c]=await Promise.all([fetch(t,{headers:n}),fetch(`${t}/files?per_page=${k}`,{headers:n}),fetch(`${t}/commits?per_page=${k}`,{headers:n}),fetch(`${t}/reviews?per_page=${k}`,{headers:n})]);if(!o.ok)return{ok:!1,error:await F(o)};const l=await o.json(),u=i.ok?await i.json():[],f=s.ok?await s.json():[],a=c.ok?await c.json():[],m=new Map;for(const d of f){const g=d.author?.login??d.commit?.author?.name??"unknown",b=d.author?.avatar_url??"";m.has(g)||m.set(g,{login:g,avatarUrl:b})}const y=await Promise.all(f.slice(0,Ie).map(async d=>{try{const g=await fetch(`${E(e.owner,e.repo)}/commits/${d.sha}`,{headers:n});return g.ok?g.json():null}catch{return console.warn(`[PRobe] Failed to fetch commit detail for ${d.sha}`),null}})),v=f.map((d,g)=>{const b=y[g];return{sha:d.sha??"",message:d.commit?.message??"",author:d.author?.login??d.commit?.author?.name??"unknown",avatarUrl:d.author?.avatar_url??"",date:d.commit?.author?.date??"",additions:b?.stats?.additions??0,deletions:b?.stats?.deletions??0}}),h=new Map;for(const d of a)!d.user?.login||d.user.login===l.user?.login||h.set(d.user.login,{login:d.user.login,avatarUrl:d.user.avatar_url??"",state:d.state});return{ok:!0,stats:{additions:l.additions??0,deletions:l.deletions??0,commits:l.commits??f.length,changedFiles:l.changed_files??u.length,comments:(l.comments??0)+(l.review_comments??0),author:{login:l.user?.login??"",avatarUrl:l.user?.avatar_url??""},createdAt:l.created_at??"",labels:(l.labels??[]).map(d=>d.name),reviewers:Array.from(h.values()),commitAuthors:Array.from(m.values()),files:u.map(d=>({filename:d.filename,additions:d.additions,deletions:d.deletions})),commitDetails:v}}}const x="claude-opus-4-6",q="en-CA",Z=8e4,ee=4e4,te=3e4,Pe=200,ne=300,oe=1e3;function ie(e){if(!e)return"";const n=Date.now()-new Date(e).getTime(),t=Math.floor(n/6e4);if(t<60)return`${t}m ago`;const o=Math.floor(t/60);return o<24?`${o}h ago`:`${Math.floor(o/24)}d ago`}function Y(e){return!e||e.length===0?"":`

## Review Guidelines
The following best-practice guidelines apply to the technologies detected in this PR.
When reviewing, check the diff against these rules and **cite specific rule names** when flagging issues.

${e.map(t=>`### ${t.name}
${t.content}`).join(`

`)}`}function H(e){return!e||e.length===0?"":`
- When the Review Guidelines section is present, proactively check the diff against those rules and cite rule names (e.g. "async-parallel", "architecture-avoid-boolean-props") when flagging issues.`}const _e=`## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diff above. If you need to reference code to make a point and it is not in the diff, say "not visible in the diff" — do not reconstruct or guess what it looks like.
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file that is invisible to you. If you cannot find something in the diff, say "I don't see this in the diff, but it may exist in an unchanged part of the file" — do not say "this doesn't exist" or "there is no instruction for this."
- **Never assert runtime behavior from static analysis alone.** You cannot test the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty. Do not state that something "will always fail" or "will silently break" unless the failure is provable from the diff context alone (e.g. a type mismatch, a missing required argument, an unreachable branch).
- **Precision over recall.** A false positive (flagging something that works correctly) wastes the reviewer's time and erodes trust in the tool. Only flag issues you have high confidence about. If your confidence is moderate, explicitly mark it as uncertain. If your confidence is low, omit it entirely. It is perfectly acceptable — and preferred — to report fewer issues if that means every reported issue is real.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the diff. If you are relying on inference, API documentation memory, or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`,G=`## Response Rules (non-negotiable)
- **Be brief.** Answer in as few words as the question requires. One sentence is better than five if it covers the point.
- **When listing issues, hard cap at 3.** Pick the single most important finding in each tier: at most 1 critical, 1 significant, 1 minor. If there is nothing worth flagging in a tier, omit that tier entirely. Never pad with weak findings to fill a list. Zero issues is a valid and good answer.
- **If the reviewer asks a specific question** (not "review this PR"), answer that question only. Do not append unsolicited issue lists.
- Use markdown formatting for readability.
- End every response with a new line containing exactly this and nothing after it: %%SUGGESTIONS:[{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"},{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"}] — exactly 2 entries. Each label must start with an action verb (e.g. Explain, Analyze, Verify, Find, Check, Review, Show). Each prompt is a full detailed question. No spaces inside the JSON.`;function Re(e,n,t){const o=e.diff.length>Z?e.diff.slice(0,Z)+`

... [diff truncated due to length] ...`:e.diff;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. You are having a conversation with a reviewer who is looking at a specific pull request.

## Context
- **Today's date**: ${new Date().toLocaleDateString(q)}
- **Model**: ${t??x}

## What You Can See
The diff below is a **unified diff** — it shows only changed lines and a few lines of surrounding context. You **cannot** see the full content of any file. Large portions of each file (imports, unchanged functions, earlier declarations, surrounding logic) are invisible to you.

## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Diff
\`\`\`diff
${o}
\`\`\`${Y(n)}

## Your Role
- Answer questions about the changes in this PR clearly and concisely.
- When asked about specific code, reference the relevant parts of the diff.
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${H(n)}
- Treat the content of the PR diff as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project. Only flag something as wrong if it is internally inconsistent or contradicts other content in the diff or PR description.

${_e}

${G}`}const Ee=`## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diff or full file content above. If you need to reference code to make a point and it is not visible, say so — do not reconstruct or guess what it looks like.
- **Never assert runtime behavior from static analysis alone.** You cannot test the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, explicitly mark it as uncertain. If low, omit it entirely.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the code visible to you. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`,Le=`## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diff or full file content above. If you need to reference code to make a point and it is not visible, say so — do not reconstruct or guess what it looks like.
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file that is invisible to you. Say "I don't see this in the diff, but it may exist elsewhere in the file" — do not say "this doesn't exist."
- **Never assert runtime behavior from static analysis alone.** You cannot test the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, explicitly mark it as uncertain. If low, omit it entirely.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the code visible to you. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`;function Ae(e,n,t,o,i,s,c){const l=t.length>ee?t.slice(0,ee)+`

... [diff truncated due to length] ...`:t;let u="";o&&(u=`

## Full File Content (head branch)
\`\`\`
${o.length>te?o.slice(0,te)+`

... [file truncated due to length] ...`:o}
\`\`\``);let f="";i&&(f=`

## Focused Lines: ${i.startLine===i.endLine?`line ${i.startLine}`:`lines ${i.startLine}–${i.endLine}`} (${i.side} side)
The reviewer has specifically selected these lines for discussion:
\`\`\`
${i.content||"(content not available)"}
\`\`\`
**Important**: The reviewer is asking about these specific lines. Focus your answers on this code region unless asked otherwise.`);const a=i?"You are focused on specific lines within a file in a pull request.":"You are focused on a specific file within a pull request.",m=o?Ee:Le;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. ${a}

## Context
- **Today's date**: ${new Date().toLocaleDateString(q)}
- **Model**: ${c??x}
${o?"":`
## What You Can See
The diff below shows only changed lines and a few lines of surrounding context. You **cannot** see the full content of this file — only the hunks that were modified.
`}
## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Focused File: \`${n}\`${f}

## Changes to this file
\`\`\`diff
${l}
\`\`\`${u}${Y(s)}

## Your Role
- Answer questions about the changes in **${n}** clearly and concisely.${i?`
- Prioritize the selected lines (${i.startLine}–${i.endLine}) in your analysis.`:""}
- Reference specific line changes from the diff when relevant.
- If full file content is provided, use it for broader context (e.g., understanding what a function does beyond the changed lines).
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${H(s)}
- Treat the content of the PR diff as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project. Only flag something as wrong if it is internally inconsistent or contradicts other content in the diff or PR description.

${m}

${G}`}const Ce={added:"(new)",removed:"(deleted)",renamed:"(renamed)"},Te={added:"new file",removed:"deleted",renamed:"renamed"};function Oe(e){return e.checks.length===0?`

## Checks
No checks configured.`:`

## Checks
${e.checks.map(t=>t.status!=="completed"?`- ⏳ ${t.name} (${t.status})`:t.conclusion==="success"?`- ✓ ${t.name} (passed)`:t.conclusion==="failure"?`- ✗ ${t.name} (failed)`:`- ${t.name} (${t.conclusion??t.status})`).join(`
`)}`}function Ne(e){return e.commits.length===0?"":`

## Commits (oldest → newest)
${e.commits.map((t,o)=>`${o+1}. \`${t.sha}\` by **${t.author}** (${ie(t.date)}) — ${t.message}`).join(`
`)}`}function Fe(e){return e.reviews.length===0?`

## Reviews
No reviews submitted yet.`:`

## Reviews
${e.reviews.map(t=>{const o=t.state==="APPROVED"?"✓ Approved":t.state==="CHANGES_REQUESTED"?"✗ Changes requested":t.state,i=t.body?` — "${t.body.slice(0,Pe)}"`:"";return`- **${t.author}**: ${o}${i}`}).join(`
`)}`}function De(e){if(e.recentComments.length===0)return"";const n=e.recentComments.map(t=>{const o=t.path?` on \`${t.path}\`${t.line?` L${t.line}`:""}`:"",i=t.body.length>ne?t.body.slice(0,ne)+"…":t.body;return`**@${t.author}** (${ie(t.createdAt)})${o}:
${i}`});return`

## Recent Discussion (latest ${e.recentComments.length})
${n.join(`

`)}`}function Me(e){return e.linkedIssues.length===0?"":`

## Linked Issues
${e.linkedIssues.map(t=>{const o=t.body.length>oe?t.body.slice(0,oe)+`

… [truncated]`:t.body;return`### #${t.number}: ${t.title}
${o}`}).join(`

`)}`}function je(e){if(e.files.length===0)return"";const n=e.files.map(t=>{const o=Ce[t.status]??"";return`- ${t.filename} ${o} +${t.additions}/-${t.deletions}`.trimEnd()});return`

## Changed Files (${e.files.length} files)
${n.join(`
`)}`}function Ue(e){const n={},t=e.split(`
`);let o=null,i=[];for(const s of t)if(s.startsWith("diff --git ")){o!==null&&(n[o]=i.join(`
`));const c=s.match(/^diff --git a\/.+ b\/(.+)$/);o=c?c[1]:null,i=[s]}else o!==null&&i.push(s);return o!==null&&i.length>0&&(n[o]=i.join(`
`)),n}function xe(e){const n=Ue(e.diff),t=e.fileContents??{},o=[...e.files].sort((s,c)=>c.additions+c.deletions-(s.additions+s.deletions)),i=[];for(const s of o){const c=n[s.filename]??"",l=t[s.filename],u=s.status==="removed",f=Te[s.status]??"modified";let m=`## File: \`${s.filename}\` (${f}, +${s.additions}/-${s.deletions})`;if(c&&(m+=`

### Diff
\`\`\`diff
${c}
\`\`\``),!u&&l){const y=l.split(`
`).length;m+=`

### Full Content — head branch (${y} lines)
\`\`\`
${l}
\`\`\``}else!u&&!l&&(m+=`

*Full file content unavailable — diff only.*`);i.push(m)}return i.join(`

---

`)}function qe(e,n,t){const o=e.fileContents!==void 0&&Object.keys(e.fileContents).length>0,i=o?Object.keys(e.fileContents):[],s=e.files.filter(f=>f.status!=="removed"&&!i.includes(f.filename)).map(f=>f.filename),c=e.mergeable===!0?"Clean (no conflicts)":e.mergeable===!1?"Has merge conflicts":"Unknown",l=o?`## What You Can See
For most files in this PR you have **both** the diff (what changed) and the **complete head-branch file content** (the full file as it exists after the change). Files where full content is available are listed below — for those files you can see all imports, type definitions, unchanged functions, and surrounding context.

Files with full content (${i.length}): ${i.map(f=>`\`${f}\``).join(", ")}${s.length>0?`

Files with diff only (${s.length}): ${s.map(f=>`\`${f}\``).join(", ")}`:""}`:`## What You Can See
The diffs below are **unified diffs** — they show only changed lines and a few lines of surrounding context. You **cannot** see the full content of any file. Large portions of each file (imports, unchanged functions, earlier declarations) are invisible to you.`,u=o?`## Epistemic Rules (non-negotiable)
- **Only quote visible code.** When referencing code in files where you have full content, you can quote any part of the file. For diff-only files, only quote lines present in the diff.
- **For full-content files, you can verify existence.** If a function, import, type, or instruction is not in the file content shown, it genuinely does not exist in that file (it may exist in another file).
- **For diff-only files, never claim code is missing.** Unchanged code outside the diff hunks is invisible to you. Say "not visible in the diff" — do not say "this doesn't exist."
- **Never assert runtime behavior from static analysis alone.** You cannot execute the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty explicitly.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, mark it as uncertain. If low, omit it.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the code visible to you. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`:`## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diffs. If code you want to reference is not in the diff, say "not visible in the diff" — do not reconstruct or guess what it looks like.
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file. Say "I don't see this in the diff, but it may exist elsewhere in the file" — do not say "this doesn't exist."
- **Never assert runtime behavior from static analysis alone.** You cannot execute the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty explicitly.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, mark it as uncertain. If low, omit it.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the diff. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. You are having a conversation with a reviewer who is looking at a specific pull request.

## Context
- **Today's date**: ${new Date().toLocaleDateString(q)}
- **Model**: ${t??x}

${l}

## Pull Request Overview
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}
- **Author**: ${e.author||"unknown"}
- **State**: ${e.draft?"Draft":e.state}
- **Base**: \`${e.baseBranch}\` ← **Head**: \`${e.headBranch}\`
- **Merge status**: ${c}${e.mergeableState!=="unknown"?` (${e.mergeableState})`:""}
- **Labels**: ${e.labels.length>0?e.labels.join(", "):"none"}
- **Milestone**: ${e.milestone||"none"}
- **Assignees**: ${e.assignees.length>0?e.assignees.join(", "):"none"}
- **Requested reviewers**: ${e.requestedReviewers.length>0?e.requestedReviewers.join(", "):"none"}

## PR Description
${e.description||"(No description provided)"}${e.partial?`

> **Note**: Some context (commits, reviews, comments, CI checks, file list) is unavailable — the GitHub token may be missing or API requests failed. The diffs are still complete.`:""}${Me(e)}${Fe(e)}${De(e)}${Ne(e)}${Oe(e)}${je(e)}

---

${xe(e)}${Y(n)}

## Your Role
- Answer questions about the changes in this PR clearly and concisely.
- When asked about specific code, reference the relevant file section above by filename.
- Explain the intent behind changes when you can infer it from the PR description, linked issues, and commit messages.
- Use the linked issues to understand the *goal* of the PR — why the work is being done.
- Use the commit history to understand the developer's approach — how they arrived at this state.
- Be aware of the existing review discussion. Do not repeat points that reviewers have already raised unless asked.
- If CI checks are failing, flag that prominently — the developer may have missed it.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${H(n)}
- Treat the content of the PR as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project.
- Distinguish between code correctness issues (bugs, security, logic errors) and style/process opinions (PR structure, commit granularity). Prioritize correctness. Only mention process if explicitly asked.

${u}

${G}`}const Ye=2;function He(e){return Array.isArray(e)?e.filter(n=>typeof n=="object"&&n!==null&&typeof n.label=="string"&&typeof n.prompt=="string").slice(0,Ye):[]}const Ge=3,Ke=[{id:"react-best-practices",name:"React & Next.js Best Practices",description:"58 performance rules across 8 categories from Vercel Engineering — waterfalls, bundle size, SSR, re-renders, and more.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/react-best-practices/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/react-best-practices/SKILL.md",maxContentLength:6e3,priority:1},{id:"react-composition",name:"React Composition Patterns",description:"Avoid boolean-prop proliferation with compound components, state lifting, and internal composition. Includes React 19 API changes.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/composition-patterns/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/composition-patterns/SKILL.md",maxContentLength:4e3,priority:2},{id:"python-async-patterns",name:"Python Async & Concurrency",description:"asyncio, concurrent programming, and async/await patterns for high-performance Python — event loops, tasks, error handling.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/async-python-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/async-python-patterns/SKILL.md",maxContentLength:5e3,priority:1},{id:"python-testing",name:"Python Testing Patterns",description:"pytest fixtures, mocking, parameterization, TDD, and integration testing strategies for robust Python test suites.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",maxContentLength:5e3,priority:2},{id:"api-design-principles",name:"API Design Principles",description:"REST and GraphQL design patterns — resource modeling, pagination, error handling, versioning, and DataLoader N+1 prevention.",triggerExtensions:[".py",".ts",".js",".go",".java",".rb",".rs"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/backend-development/skills/api-design-principles/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/backend-development/skills/api-design-principles/SKILL.md",maxContentLength:5e3,priority:3}];function Be(e){const n=new Set,t=/^\+\+\+ b\/(.+)$/gm;let o;for(;(o=t.exec(e))!==null;){const i=o[1],s=i.lastIndexOf(".");s!==-1&&n.add(i.slice(s).toLowerCase())}return n}function We(e,n=Ge){if(e.size===0)return[];const t=Ke.filter(o=>o.triggerExtensions.some(i=>e.has(i)));return t.sort((o,i)=>o.priority-i.priority),t.slice(0,n)}const Xe=1440*60*1e3;function Je(e){return e.replace(/^---[\s\S]*?---\s*/,"")}async function Ve(e){const n=`skill:${e.id}`,t=await new Promise(o=>{chrome.storage.local.get([n],i=>{const s=i[n];s&&Date.now()-s.fetchedAt<Xe?o(s):o(null)})});if(t)return t.content;try{const o=await fetch(e.rawUrl);if(!o.ok)return console.warn(`[PRobe] Failed to fetch skill "${e.id}": HTTP ${o.status}`),null;let i=Je(await o.text());if(i.length>e.maxContentLength){const s=i.lastIndexOf(`
`,e.maxContentLength);i=i.slice(0,s>0?s:e.maxContentLength)+`

… [truncated for brevity]`}return chrome.storage.local.set({[n]:{content:i,fetchedAt:Date.now()}},()=>{chrome.runtime.lastError&&console.warn("[PRobe] Failed to cache skill:",chrome.runtime.lastError.message)}),i}catch(o){return console.warn(`[PRobe] Error fetching skill "${e.id}":`,o),null}}async function ze(e){const n=Be(e),t=We(n);return t.length===0?[]:(await Promise.all(t.map(async i=>{const s=await Ve(i);return s?{name:i.name,content:s,sourceUrl:i.sourceUrl,description:i.description}:null}))).filter(i=>i!==null)}const se="2023-06-01";function re(e,n,t,o){return{endpoint:`${n.replace(/\/$/,"")}/v1/messages`,init:{method:"POST",headers:{"Content-Type":"application/json","x-api-key":e,"anthropic-version":se},body:JSON.stringify(t),signal:o}}}function ae(e,n,t,o){return{endpoint:`${n.replace(/\/$/,"")}/openai/v1/chat/completions`,init:{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`},body:JSON.stringify(t),signal:o}}}function Qe(e,n){return e==="openai"?n.choices?.[0]?.message?.content??"":n.content?.[0]?.text??""}function Ze(e,n){if(e==="openai")return n.choices?.[0]?.delta?.content??null;if(n.type==="content_block_delta"){const t=n.delta;if(t?.type==="text_delta")return t.text??null}return null}const le=500,ce=4096,et=500,tt=10;async function K(){return new Promise(e=>{chrome.storage.sync.get([w.API_KEY,w.LLM_PROVIDER,w.MODEL_NAME,w.PROXY_URL],n=>{const t=n[w.LLM_PROVIDER]||"anthropic",o=n[w.PROXY_URL]||"",i=n[w.MODEL_NAME]||he[t];e({provider:t,apiKey:n[w.API_KEY]??null,modelName:i,proxyUrl:o.startsWith("https://")?o:fe})})})}async function nt(e){const{provider:n,apiKey:t,modelName:o,proxyUrl:i}=await K();if(!t)return{ok:!1,error:"No API key configured."};const s=[...e.stats.files].sort((a,m)=>m.additions+m.deletions-(a.additions+a.deletions)).slice(0,tt).map(a=>`${a.filename} (+${a.additions}/-${a.deletions})`).join(`
`),c=`You are helping a code reviewer quickly understand a pull request.

Today's date: ${new Date().toLocaleDateString("en-CA")}

PR #${e.number}: ${e.title}
${e.description?`Description: ${e.description.slice(0,et)}`:""}

Stats: ${e.stats.commits} commits, ${e.stats.changedFiles} files, +${e.stats.additions}/-${e.stats.deletions} lines, ${e.stats.comments} comments
Authors: ${e.stats.commitAuthors.map(a=>a.login).join(", ")}
Reviewers: ${e.stats.reviewers.map(a=>`${a.login} (${a.state})`).join(", ")||"none yet"}

Top changed files:
${s}

Treat the PR content as authoritative. Return ONLY a JSON array of exactly 2 objects, no other text:
[{"label":"<2–4 word label>","prompt":"<detailed question a reviewer would ask about this PR>"},{"label":"<2–4 word label>","prompt":"<detailed question a reviewer would ask about this PR>"}]

Each label must be 2–4 words and start with an action verb (e.g. Analyze, Verify, Understand, Check, Review, Find, Explain). Each prompt must be a specific, detailed question about a real concern in this PR (file paths, risk areas, logic). No generic prompts.`,l="You are a concise code review assistant. Output only valid JSON.";let u,f;n==="openai"?{endpoint:u,init:f}=ae(t,i,{model:o,max_tokens:le,messages:[{role:"system",content:l},{role:"user",content:c}]}):{endpoint:u,init:f}=re(t,i,{model:o,max_tokens:le,system:l,messages:[{role:"user",content:c}]});try{const a=await fetch(u,f);if(!a.ok)return{ok:!1,error:`LLM error (${a.status})`};const m=await a.json(),y=Qe(n,m);let v=[];try{const h=y.match(/\[[\s\S]*\]/);h&&(v=He(JSON.parse(h[0])))}catch{}return{ok:!0,bullets:v}}catch(a){return{ok:!1,error:a instanceof Error?a.message:"LLM call failed"}}}async function ot(e,n,t,o,i){const{provider:s,apiKey:c,modelName:l,proxyUrl:u}=await K();if(!c){R(e,{type:"error",message:"No API key configured. Click the PRobe extension icon to add your API key."});return}const f=await ze(t.diff);f.length>0&&R(e,{type:"skills",skills:f.map(h=>({name:h.name,sourceUrl:h.sourceUrl,description:h.description}))});let a;t.focusedFile?a=Ae(t,t.focusedFile,t.diff,t.focusedFileContent,t.focusedLineRange,f,l):i?a=qe(i,f,l):a=Re(t,f,l),R(e,{type:"system-prompt",content:a});const m=n.map(h=>({role:h.role,content:h.content}));let y,v;s==="openai"?{endpoint:y,init:v}=ae(c,u,{model:l,max_tokens:ce,stream:!0,messages:[{role:"system",content:a},...m]},o):{endpoint:y,init:v}=re(c,u,{model:l,max_tokens:ce,stream:!0,system:a,messages:m},o);try{const h=await fetch(y,v);if(!h.ok){const b=await h.text();let I=`${s==="openai"?"OpenAI":"Anthropic"} API error (${h.status})`;try{I=JSON.parse(b)?.error?.message??I}catch{}R(e,{type:"error",message:I});return}const O=h.body?.getReader();if(!O){R(e,{type:"error",message:"No response body"});return}const d=new TextDecoder;let g="";for(;;){const{done:b,value:D}=await O.read();if(b)break;g+=d.decode(D,{stream:!0});const I=g.split(`
`);g=I.pop()??"";for(const L of I){if(!L.startsWith("data: "))continue;const M=L.slice(6).trim();if(M!=="[DONE]")try{const B=JSON.parse(M),N=Ze(s,B);N&&R(e,{type:"chunk",content:N})}catch{}}}R(e,{type:"done"})}catch(h){if(o.aborted)return;R(e,{type:"error",message:h instanceof Error?h.message:"Unknown error"})}}async function it(e,n,t){const o=e==="openai"?`${t.replace(/\/$/,"")}/openai/v1/models`:`${t.replace(/\/$/,"")}/v1/models`,i=e==="openai"?{Authorization:`Bearer ${n}`}:{"x-api-key":n,"anthropic-version":se},s=await fetch(o,{method:"GET",headers:i});if(!s.ok)throw new Error(`HTTP ${s.status}`);return(await s.json()).data.slice().sort((l,u)=>(u.created??0)-(l.created??0)).map(l=>l.id)}async function st(e,n){try{const{proxyUrl:t}=await K();return{ok:!0,models:await it(e,n,t)}}catch(t){return{ok:!1,error:t instanceof Error?t.message:"Failed to fetch models"}}}const T=new Map;function rt(e,n){const t=`https://github.com/${e.owner}/${e.repo}/pull/${e.number}.diff`;return P(fetch(t).then(async o=>o.ok?{ok:!0,diff:await o.text()}:{ok:!1,error:`HTTP ${o.status}: ${o.statusText}`}),n)}function at(e,n){const t=`https://raw.githubusercontent.com/${e.owner}/${e.repo}/${e.branch}/${e.path}`;return P(fetch(t).then(async o=>o.ok?{ok:!0,content:await o.text()}:{ok:!1,error:`HTTP ${o.status}: ${o.statusText}`}),n)}function lt(e,n){const t=new AbortController;return T.set(e.requestId,t),ke(e,t.signal).then(o=>{T.delete(e.requestId),n(o)}).catch(o=>{T.delete(e.requestId),!t.signal.aborted&&n({ok:!1,error:o instanceof Error?o.message:"Unknown error"})}),!0}const ct={"open-popup":(e,n)=>(chrome.action.openPopup().then(()=>n({ok:!0})).catch(()=>n({ok:!1})),!0),"fetch-diff":(e,n)=>rt(e,n),"fetch-file":(e,n)=>at(e,n),"fetch-enriched-context":(e,n)=>lt(e,n),"cancel-enriched-context":e=>{const n=e;T.get(n.requestId)?.abort(),T.delete(n.requestId)},"post-comment":(e,n)=>P(ye(e),n),"post-review-comment":(e,n)=>P(ge(e),n),"submit-review":(e,n)=>P(be(e),n),"fetch-pr-stats":(e,n)=>P(Se(e),n),"generate-pr-summary":(e,n)=>P(nt(e),n),"fetch-models":(e,n)=>{const t=e;return P(st(t.provider,t.apiKey),n)}};return chrome.runtime.onMessage.addListener((e,n,t)=>{const o=ct[e.type];if(o)return o(e,t)}),chrome.runtime.onConnect.addListener(e=>{if(e.name!=="probe-chat")return;let n=null;e.onMessage.addListener(async t=>{if(t.type==="stop"){n?.abort();return}t.type==="chat"&&(n=new AbortController,await ot(e,t.payload.messages,t.payload.context,n.signal,t.payload.enrichedContext))}),e.onDisconnect.addListener(()=>{n?.abort()})}),j.apiBase=E,Object.defineProperty(j,Symbol.toStringTag,{value:"Module"}),j})({});
