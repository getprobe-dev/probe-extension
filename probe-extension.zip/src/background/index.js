(function(){"use strict";const U="https://pr-sidekick-proxy.sgunturi.workers.dev",m={API_KEY:"anthropic_api_key",PROXY_URL:"proxy_url",GITHUB_TOKEN:"github_token"};function P(e){return!e||e.length===0?"":`

## Review Guidelines
The following best-practice guidelines apply to the technologies detected in this PR.
When reviewing, check the diff against these rules and **cite specific rule names** when flagging issues.

${e.map(t=>`### ${t.name}
${t.content}`).join(`

`)}`}function S(e){return!e||e.length===0?"":`
- When the Review Guidelines section is present, proactively check the diff against those rules and cite rule names (e.g. "async-parallel", "architecture-avoid-boolean-props") when flagging issues.`}function _(e,o){const t=e.diff.length>8e4?e.diff.slice(0,8e4)+`

... [diff truncated due to length] ...`:e.diff;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. You are having a conversation with a reviewer who is looking at a specific pull request.

## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Diff
\`\`\`diff
${t}
\`\`\`${P(o)}

## Your Role
- Answer questions about the changes in this PR clearly and concisely.
- When asked about specific code, reference the relevant parts of the diff.
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${S(o)}
- Be direct. Don't pad your answers with filler.
- Use markdown formatting for readability.`}function T(e,o,t,r,n,a){const i=t.length>4e4?t.slice(0,4e4)+`

... [diff truncated due to length] ...`:t;let l="";r&&(l=`

## Full File Content (head branch)
\`\`\`
${r.length>3e4?r.slice(0,3e4)+`

... [file truncated due to length] ...`:r}
\`\`\``);let d="";return n&&(d=`

## Focused Lines: ${n.startLine===n.endLine?`line ${n.startLine}`:`lines ${n.startLine}–${n.endLine}`} (${n.side} side)
The reviewer has specifically selected these lines for discussion:
\`\`\`
${n.content||"(content not available)"}
\`\`\`
**Important**: The reviewer is asking about these specific lines. Focus your answers on this code region unless asked otherwise.`),`You are PRobe, an AI assistant that helps developers review GitHub pull requests. ${n?"You are focused on specific lines within a file in a pull request.":"You are focused on a specific file within a pull request."}

## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Focused File: \`${o}\`${d}

## Changes to this file
\`\`\`diff
${i}
\`\`\`${l}${P(a)}

## Your Role
- Answer questions about the changes in **${o}** clearly and concisely.${n?`
- Prioritize the selected lines (${n.startLine}–${n.endLine}) in your analysis.`:""}
- Reference specific line changes from the diff when relevant.
- If full file content is provided, use it for broader context (e.g., understanding what a function does beyond the changed lines).
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${S(a)}
- Be direct. Don't pad your answers with filler.
- Use markdown formatting for readability.`}const I=[{id:"react-best-practices",name:"React & Next.js Best Practices",description:"58 performance rules across 8 categories from Vercel Engineering — waterfalls, bundle size, SSR, re-renders, and more.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/react-best-practices/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/react-best-practices/SKILL.md",maxContentLength:6e3,priority:1},{id:"react-composition",name:"React Composition Patterns",description:"Avoid boolean-prop proliferation with compound components, state lifting, and internal composition. Includes React 19 API changes.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/composition-patterns/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/composition-patterns/SKILL.md",maxContentLength:4e3,priority:2},{id:"python-async-patterns",name:"Python Async & Concurrency",description:"asyncio, concurrent programming, and async/await patterns for high-performance Python — event loops, tasks, error handling.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/async-python-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/async-python-patterns/SKILL.md",maxContentLength:5e3,priority:1},{id:"python-testing",name:"Python Testing Patterns",description:"pytest fixtures, mocking, parameterization, TDD, and integration testing strategies for robust Python test suites.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",maxContentLength:5e3,priority:2},{id:"api-design-principles",name:"API Design Principles",description:"REST and GraphQL design patterns — resource modeling, pagination, error handling, versioning, and DataLoader N+1 prevention.",triggerExtensions:[".py",".ts",".js",".go",".java",".rb",".rs"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/backend-development/skills/api-design-principles/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/backend-development/skills/api-design-principles/SKILL.md",maxContentLength:5e3,priority:3}];function E(e){const o=new Set,t=/^\+\+\+ b\/(.+)$/gm;let r;for(;(r=t.exec(e))!==null;){const n=r[1],a=n.lastIndexOf(".");a!==-1&&o.add(n.slice(a).toLowerCase())}return o}function A(e,o=3){if(e.size===0)return[];const t=I.filter(r=>r.triggerExtensions.some(n=>e.has(n)));return t.sort((r,n)=>r.priority-n.priority),t.slice(0,o)}chrome.runtime.onMessage.addListener((e,o,t)=>{if(e.type==="fetch-diff"){const r=`https://github.com/${e.owner}/${e.repo}/pull/${e.number}.diff`;return fetch(r).then(async n=>{if(!n.ok){t({ok:!1,error:`HTTP ${n.status}: ${n.statusText}`});return}t({ok:!0,diff:await n.text()})}).catch(n=>{t({ok:!1,error:n instanceof Error?n.message:"Network error"})}),!0}if(e.type==="fetch-file"){const r=`https://raw.githubusercontent.com/${e.owner}/${e.repo}/${e.branch}/${e.path}`;return fetch(r).then(async n=>{if(!n.ok){t({ok:!1,error:`HTTP ${n.status}: ${n.statusText}`});return}t({ok:!0,content:await n.text()})}).catch(n=>{t({ok:!1,error:n instanceof Error?n.message:"Network error"})}),!0}if(e.type==="post-comment")return C(e).then(t).catch(r=>{t({ok:!1,error:r instanceof Error?r.message:"Unknown error"})}),!0;if(e.type==="post-review-comment")return N(e).then(t).catch(r=>{t({ok:!1,error:r instanceof Error?r.message:"Unknown error"})}),!0;if(e.type==="submit-review")return O(e).then(t).catch(r=>{t({ok:!1,error:r instanceof Error?r.message:"Unknown error"})}),!0;if(e.type==="fetch-pr-stats")return K(e).then(t).catch(r=>{t({ok:!1,error:r instanceof Error?r.message:"Unknown error"})}),!0;if(e.type==="generate-pr-summary")return j(e).then(t).catch(r=>{t({ok:!1,error:r instanceof Error?r.message:"Unknown error"})}),!0});async function k(){const e=await R();return e?{Authorization:`Bearer ${e}`,Accept:"application/vnd.github+json","Content-Type":"application/json","X-GitHub-Api-Version":"2022-11-28"}:null}async function C(e){const o=await k();if(!o)return{ok:!1,error:"No GitHub token configured. Click the PRobe extension icon to add one."};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/issues/${e.number}/comments`,r=await fetch(t,{method:"POST",headers:o,body:JSON.stringify({body:e.body})});return r.ok?{ok:!0,url:(await r.json()).html_url}:{ok:!1,error:await $(r)}}async function N(e){const o=await k();if(!o)return{ok:!1,error:"No GitHub token configured. Click the PRobe extension icon to add one."};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}/reviews`,r=await fetch(t,{method:"POST",headers:o,body:JSON.stringify({event:"COMMENT",comments:[{path:e.path,body:e.body,line:e.line,side:e.side}]})});return r.ok?{ok:!0,url:(await r.json()).html_url}:{ok:!1,error:await $(r)}}async function O(e){const o=await k();if(!o)return{ok:!1,error:"No GitHub token configured. Click the PRobe extension icon to add one."};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}/reviews`,r=await fetch(t,{method:"POST",headers:o,body:JSON.stringify({body:e.body||void 0,event:e.event,comments:e.comments.map(a=>({path:a.path,body:a.body,line:a.line,side:a.side}))})});return r.ok?{ok:!0,url:(await r.json()).html_url}:{ok:!1,error:await $(r)}}async function $(e){let o=`GitHub API error (${e.status})`;try{o=JSON.parse(await e.text())?.message??o}catch{}return o}async function R(){return new Promise(e=>{chrome.storage.sync.get([m.GITHUB_TOKEN],o=>{e(o[m.GITHUB_TOKEN]??null)})})}async function K(e){const o=await k();if(!o)return{ok:!1,error:"No GitHub token configured."};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}`,[r,n,a,i]=await Promise.all([fetch(t,{headers:o}),fetch(`${t}/files?per_page=100`,{headers:o}),fetch(`${t}/commits?per_page=100`,{headers:o}),fetch(`${t}/reviews?per_page=100`,{headers:o})]);if(!r.ok)return{ok:!1,error:await $(r)};const l=await r.json(),d=n.ok?await n.json():[],h=a.ok?await a.json():[],c=i.ok?await i.json():[],y=new Map;for(const s of h){const u=s.author?.login??s.commit?.author?.name??"unknown",f=s.author?.avatar_url??"";y.has(u)||y.set(u,{login:u,avatarUrl:f})}const v=await Promise.all(h.slice(0,30).map(async s=>{try{const u=await fetch(`https://api.github.com/repos/${e.owner}/${e.repo}/commits/${s.sha}`,{headers:o});return u.ok?u.json():null}catch{return null}})),b=h.map((s,u)=>{const f=v[u];return{sha:s.sha??"",message:s.commit?.message??"",author:s.author?.login??s.commit?.author?.name??"unknown",avatarUrl:s.author?.avatar_url??"",date:s.commit?.author?.date??"",additions:f?.stats?.additions??0,deletions:f?.stats?.deletions??0}}),w=new Map;for(const s of c)!s.user?.login||s.user.login===l.user?.login||w.set(s.user.login,{login:s.user.login,avatarUrl:s.user.avatar_url??"",state:s.state});return{ok:!0,stats:{additions:l.additions??0,deletions:l.deletions??0,commits:l.commits??h.length,changedFiles:l.changed_files??d.length,comments:(l.comments??0)+(l.review_comments??0),author:{login:l.user?.login??"",avatarUrl:l.user?.avatar_url??""},createdAt:l.created_at??"",labels:(l.labels??[]).map(s=>s.name),reviewers:Array.from(w.values()),commitAuthors:Array.from(y.values()),files:d.map(s=>({filename:s.filename,additions:s.additions,deletions:s.deletions})),commitDetails:b}}}async function j(e){const{apiKey:o,proxyUrl:t}=await x();if(!o)return{ok:!1,error:"No API key configured."};const r=[...e.stats.files].sort((i,l)=>l.additions+l.deletions-(i.additions+i.deletions)).slice(0,10).map(i=>`${i.filename} (+${i.additions}/-${i.deletions})`).join(`
`),n=`You are helping a code reviewer quickly understand a pull request.

PR #${e.number}: ${e.title}
${e.description?`Description: ${e.description.slice(0,500)}`:""}

Stats: ${e.stats.commits} commits, ${e.stats.changedFiles} files, +${e.stats.additions}/-${e.stats.deletions} lines, ${e.stats.comments} comments
Authors: ${e.stats.commitAuthors.map(i=>i.login).join(", ")}
Reviewers: ${e.stats.reviewers.map(i=>`${i.login} (${i.state})`).join(", ")||"none yet"}

Top changed files:
${r}

Provide exactly 3 concise bullet points (each under 80 chars) about what a reviewer should focus on. Be specific about file paths and risk areas. Return ONLY the 3 bullets, one per line, starting with "- ". No other text.`,a=`${t.replace(/\/$/,"")}/v1/messages`;try{const i=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":o,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:300,system:"You are a concise code review assistant. Output only bullet points.",messages:[{role:"user",content:n}]})});return i.ok?{ok:!0,bullets:((await i.json()).content?.[0]?.text??"").split(`
`).map(c=>c.replace(/^[-•*]\s*/,"").trim()).filter(c=>c.length>0).slice(0,3)}:{ok:!1,error:`LLM error (${i.status})`}}catch(i){return{ok:!1,error:i instanceof Error?i.message:"LLM call failed"}}}chrome.runtime.onConnect.addListener(e=>{if(e.name!=="probe-chat")return;let o=null;e.onMessage.addListener(async t=>{if(t.type==="stop"){o?.abort();return}t.type==="chat"&&(o=new AbortController,await H(e,t.payload.messages,t.payload.context,o.signal))}),e.onDisconnect.addListener(()=>{o?.abort()})});async function x(){return new Promise(e=>{chrome.storage.sync.get([m.API_KEY,m.PROXY_URL],o=>{e({apiKey:o[m.API_KEY]??null,proxyUrl:o[m.PROXY_URL]||U})})})}function p(e,o){try{e.postMessage(o)}catch{}}const F=1440*60*1e3;function D(e){return e.replace(/^---[\s\S]*?---\s*/,"")}async function Y(e){const o=`skill:${e.id}`,t=await new Promise(r=>{chrome.storage.local.get([o],n=>{const a=n[o];a&&Date.now()-a.fetchedAt<F?r(a):r(null)})});if(t)return t.content;try{const r=await fetch(e.rawUrl);if(!r.ok)return null;let n=D(await r.text());if(n.length>e.maxContentLength){const a=n.lastIndexOf(`
`,e.maxContentLength);n=n.slice(0,a>0?a:e.maxContentLength)+`

… [truncated for brevity]`}return chrome.storage.local.set({[o]:{content:n,fetchedAt:Date.now()}}),n}catch{return null}}async function G(e){const o=E(e),t=A(o);return t.length===0?[]:(await Promise.all(t.map(async n=>{const a=await Y(n);return a?{name:n.name,content:a,sourceUrl:n.sourceUrl,description:n.description}:null}))).filter(n=>n!==null)}async function H(e,o,t,r){const{apiKey:n,proxyUrl:a}=await x();if(!n){p(e,{type:"error",message:"No API key configured. Click the PRobe extension icon to add your Anthropic API key."});return}const i=await G(t.diff);i.length>0&&p(e,{type:"skills",skills:i.map(c=>({name:c.name,sourceUrl:c.sourceUrl,description:c.description}))});const l=t.focusedFile?T(t,t.focusedFile,t.diff,t.focusedFileContent,t.focusedLineRange,i):_(t,i),d=o.map(c=>({role:c.role,content:c.content})),h=`${a.replace(/\/$/,"")}/v1/messages`;try{const c=await fetch(h,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":n,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:4096,stream:!0,system:l,messages:d}),signal:r});if(!c.ok){const w=await c.text();let g=`Anthropic API error (${c.status})`;try{g=JSON.parse(w)?.error?.message??g}catch{}p(e,{type:"error",message:g});return}const y=c.body?.getReader();if(!y){p(e,{type:"error",message:"No response body"});return}const v=new TextDecoder;let b="";for(;;){const{done:w,value:g}=await y.read();if(w)break;b+=v.decode(g,{stream:!0});const s=b.split(`
`);b=s.pop()??"";for(const u of s){if(!u.startsWith("data: "))continue;const f=u.slice(6).trim();if(f!=="[DONE]")try{const L=JSON.parse(f);L.type==="content_block_delta"&&L.delta?.type==="text_delta"&&p(e,{type:"chunk",content:L.delta.text})}catch{}}}p(e,{type:"done"})}catch(c){if(r.aborted)return;p(e,{type:"error",message:c instanceof Error?c.message:"Unknown error"})}}})();
