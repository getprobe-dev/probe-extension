(function(){"use strict";function k(e,n){return e.then(n).catch(t=>{n({ok:!1,error:t instanceof Error?t.message:"Unknown error"})}),!0}function v(e,n){try{e.postMessage(n)}catch{}}const V="https://pr-sidekick-proxy.sgunturi.workers.dev",P={API_KEY:"anthropic_api_key",PROXY_URL:"proxy_url",GITHUB_TOKEN:"github_token"},X="2022-11-28";async function Z(){return new Promise(e=>{chrome.storage.sync.get([P.GITHUB_TOKEN],n=>{e(n[P.GITHUB_TOKEN]??null)})})}async function C(){const e=await Z();return e?{Authorization:`Bearer ${e}`,Accept:"application/vnd.github+json","Content-Type":"application/json","X-GitHub-Api-Version":X}:null}async function T(e){let n=`GitHub API error (${e.status})`;try{n=JSON.parse(await e.text())?.message??n}catch{}return n}const _="No GitHub token configured. Click the PRobe extension icon to add one.";async function Q(e){const n=await C();if(!n)return{ok:!1,error:_};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/issues/${e.number}/comments`,i=await fetch(t,{method:"POST",headers:n,body:JSON.stringify({body:e.body})});return i.ok?{ok:!0,url:(await i.json()).html_url}:{ok:!1,error:await T(i)}}async function ee(e){const n=await C();if(!n)return{ok:!1,error:_};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}/reviews`,i=await fetch(t,{method:"POST",headers:n,body:JSON.stringify({event:"COMMENT",comments:[{path:e.path,body:e.body,line:e.line,side:e.side}]})});return i.ok?{ok:!0,url:(await i.json()).html_url}:{ok:!1,error:await T(i)}}async function te(e){const n=await C();if(!n)return{ok:!1,error:_};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}/reviews`,i=await fetch(t,{method:"POST",headers:n,body:JSON.stringify({body:e.body||void 0,event:e.event,comments:e.comments.map(a=>({path:a.path,body:a.body,line:a.line,side:a.side}))})});return i.ok?{ok:!0,url:(await i.json()).html_url}:{ok:!1,error:await T(i)}}const ne=4e5,Y=3e4;async function ie(e,n){const t=await C();if(n.aborted)return{ok:!1,error:"Cancelled"};const i=`https://api.github.com/repos/${e.owner}/${e.repo}`,o=`https://github.com/${e.owner}/${e.repo}/pull/${e.number}.diff`,a={diff:fetch(o,{signal:n}),pr:t?fetch(`${i}/pulls/${e.number}`,{headers:t,signal:n}):Promise.reject("no token"),commits:t?fetch(`${i}/pulls/${e.number}/commits?per_page=100`,{headers:t,signal:n}):Promise.reject("no token"),reviews:t?fetch(`${i}/pulls/${e.number}/reviews?per_page=100`,{headers:t,signal:n}):Promise.reject("no token"),issueComments:t?fetch(`${i}/issues/${e.number}/comments?per_page=100`,{headers:t,signal:n}):Promise.reject("no token"),reviewComments:t?fetch(`${i}/pulls/${e.number}/comments?per_page=100`,{headers:t,signal:n}):Promise.reject("no token"),files:t?fetch(`${i}/pulls/${e.number}/files?per_page=100`,{headers:t,signal:n}):Promise.reject("no token")},l=await Promise.allSettled(Object.values(a)),u=Object.keys(a),r={};for(let s=0;s<u.length;s++){const f=l[s];r[u[s]]=f.status==="fulfilled"&&f.value.ok?f.value:null}const p=r.diff?await r.diff.text():"";if(!p)return{ok:!1,error:"Failed to fetch PR diff"};const d=r.pr?await r.pr.json():null,h=d?.title??`PR #${e.number}`,y=d?.body??"",E=d?.user?.login??"",$=d?.base?.ref??"main",S=d?.head?.ref??"",c=d?.head?.sha??"",g=(r.commits?await r.commits.json():[]).map(s=>({sha:s.sha.slice(0,7),message:s.commit.message.split(`
`)[0],author:s.author?.login??s.commit.author?.name??"unknown",date:s.commit.author?.date??""})),O=r.reviews?await r.reviews.json():[],I=new Map;for(const s of O)s.user?.login&&I.set(s.user.login,{author:s.user.login,state:s.state,body:s.body??""});const B=Array.from(I.values()),_e=r.issueComments?await r.issueComments.json():[],Ne=r.reviewComments?await r.reviewComments.json():[],H=[..._e.map(s=>({author:s.user?.login??"unknown",body:s.body,createdAt:s.created_at})),...Ne.map(s=>({author:s.user?.login??"unknown",body:s.body,path:s.path,line:s.line??void 0,createdAt:s.created_at}))];H.sort((s,f)=>new Date(f.createdAt).getTime()-new Date(s.createdAt).getTime());const je=H.slice(0,5),q=(r.files?await r.files.json():[]).map(s=>({filename:s.filename,status:s.status,additions:s.additions,deletions:s.deletions}));let W=[];if(t&&c&&!n.aborted)try{const s=await fetch(`${i}/commits/${c}/check-runs?per_page=100`,{headers:t,signal:n});s.ok&&(W=(await s.json()).check_runs.map(w=>({name:w.name,status:w.status,conclusion:w.conclusion})))}catch{}const J=[];if(t&&y&&!n.aborted){const s=new Set,f=/(?:closes|fixes|resolves|part of|related:?)\s+#(\d+)/gi;let w;for(;(w=f.exec(y))!==null;)s.add(parseInt(w[1],10));const R=await Promise.allSettled([...s].map(async b=>{const z=await fetch(`${i}/issues/${b}`,{headers:t,signal:n});if(!z.ok)return null;const U=await z.json();return{number:U.number,title:U.title,body:U.body??""}}));for(const b of R)b.status==="fulfilled"&&b.value&&J.push(b.value)}const qe=!t||!d&&g.length===0&&B.length===0&&q.length===0,D=[...q].filter(s=>s.status!=="removed").sort((s,f)=>f.additions+f.deletions-(s.additions+s.deletions)),De=`https://raw.githubusercontent.com/${e.owner}/${e.repo}/${c}`,F={};let x=ne;if(c&&!n.aborted){const s=await Promise.allSettled(D.map(f=>fetch(`${De}/${f.filename}`,{signal:n})));for(let f=0;f<D.length&&!(x<=0);f++){const w=s[f];if(w.status!=="fulfilled"||!w.value.ok)continue;const R=await w.value.text();if(R.slice(0,1024).includes("\0"))continue;const b=R.length>Y?R.slice(0,Y)+`
… [truncated]`:R;if(b.length>x)break;F[D[f].filename]=b,x-=b.length}}return{ok:!0,context:{owner:e.owner,repo:e.repo,number:e.number,title:h,description:y,diff:p,headBranch:S,baseBranch:$,author:E,state:d?.state??"open",draft:d?.draft??!1,mergeable:d?.mergeable??null,mergeableState:d?.mergeable_state??"unknown",labels:(d?.labels??[]).map(s=>s.name),milestone:d?.milestone?.title??"",assignees:(d?.assignees??[]).map(s=>s.login),requestedReviewers:(d?.requested_reviewers??[]).map(s=>s.login),commits:g,reviews:B,recentComments:je,checks:W,files:q,linkedIssues:J,fileContents:Object.keys(F).length>0?F:void 0,...qe?{partial:!0}:{}}}}const oe=30;async function se(e){const n=await C();if(!n)return{ok:!1,error:"No GitHub token configured."};const t=`https://api.github.com/repos/${e.owner}/${e.repo}/pulls/${e.number}`,[i,o,a,l]=await Promise.all([fetch(t,{headers:n}),fetch(`${t}/files?per_page=100`,{headers:n}),fetch(`${t}/commits?per_page=100`,{headers:n}),fetch(`${t}/reviews?per_page=100`,{headers:n})]);if(!i.ok)return{ok:!1,error:await T(i)};const u=await i.json(),r=o.ok?await o.json():[],p=a.ok?await a.json():[],d=l.ok?await l.json():[],h=new Map;for(const c of p){const m=c.author?.login??c.commit?.author?.name??"unknown",g=c.author?.avatar_url??"";h.has(m)||h.set(m,{login:m,avatarUrl:g})}const y=await Promise.all(p.slice(0,oe).map(async c=>{try{const m=await fetch(`https://api.github.com/repos/${e.owner}/${e.repo}/commits/${c.sha}`,{headers:n});return m.ok?m.json():null}catch{return null}})),E=p.map((c,m)=>{const g=y[m];return{sha:c.sha??"",message:c.commit?.message??"",author:c.author?.login??c.commit?.author?.name??"unknown",avatarUrl:c.author?.avatar_url??"",date:c.commit?.author?.date??"",additions:g?.stats?.additions??0,deletions:g?.stats?.deletions??0}}),$=new Map;for(const c of d)!c.user?.login||c.user.login===u.user?.login||$.set(c.user.login,{login:c.user.login,avatarUrl:c.user.avatar_url??"",state:c.state});return{ok:!0,stats:{additions:u.additions??0,deletions:u.deletions??0,commits:u.commits??p.length,changedFiles:u.changed_files??r.length,comments:(u.comments??0)+(u.review_comments??0),author:{login:u.user?.login??"",avatarUrl:u.user?.avatar_url??""},createdAt:u.created_at??"",labels:(u.labels??[]).map(c=>c.name),reviewers:Array.from($.values()),commitAuthors:Array.from(h.values()),files:r.map(c=>({filename:c.filename,additions:c.additions,deletions:c.deletions})),commitDetails:E}}}const A="claude-opus-4-6";function N(e){return!e||e.length===0?"":`

## Review Guidelines
The following best-practice guidelines apply to the technologies detected in this PR.
When reviewing, check the diff against these rules and **cite specific rule names** when flagging issues.

${e.map(t=>`### ${t.name}
${t.content}`).join(`

`)}`}function j(e){return!e||e.length===0?"":`
- When the Review Guidelines section is present, proactively check the diff against those rules and cite rule names (e.g. "async-parallel", "architecture-avoid-boolean-props") when flagging issues.`}function ae(e,n){const t=e.diff.length>8e4?e.diff.slice(0,8e4)+`

... [diff truncated due to length] ...`:e.diff;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. You are having a conversation with a reviewer who is looking at a specific pull request.

## Context
- **Today's date**: ${new Date().toLocaleDateString("en-CA")}
- **Model**: ${A}

## What You Can See
The diff below is a **unified diff** — it shows only changed lines and a few lines of surrounding context. You **cannot** see the full content of any file. Large portions of each file (imports, unchanged functions, earlier declarations, surrounding logic) are invisible to you.

## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Diff
\`\`\`diff
${t}
\`\`\`${N(n)}

## Your Role
- Answer questions about the changes in this PR clearly and concisely.
- When asked about specific code, reference the relevant parts of the diff.
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${j(n)}
- Treat the content of the PR diff as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project. Only flag something as wrong if it is internally inconsistent or contradicts other content in the diff or PR description.

## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diff above. If you need to reference code to make a point and it is not in the diff, say "not visible in the diff" — do not reconstruct or guess what it looks like.
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file that is invisible to you. If you cannot find something in the diff, say "I don't see this in the diff, but it may exist in an unchanged part of the file" — do not say "this doesn't exist" or "there is no instruction for this."
- **Never assert runtime behavior from static analysis alone.** You cannot test the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty. Do not state that something "will always fail" or "will silently break" unless the failure is provable from the diff context alone (e.g. a type mismatch, a missing required argument, an unreachable branch).
- **Precision over recall.** A false positive (flagging something that works correctly) wastes the reviewer's time and erodes trust in the tool. Only flag issues you have high confidence about. If your confidence is moderate, explicitly mark it as uncertain. If your confidence is low, omit it entirely. It is perfectly acceptable — and preferred — to report fewer issues if that means every reported issue is real.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the diff. If you are relying on inference, API documentation memory, or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.

## Response Rules (non-negotiable)
- **Be brief.** Answer in as few words as the question requires. One sentence is better than five if it covers the point.
- **When listing issues, hard cap at 3.** Pick the single most important finding in each tier: at most 1 critical, 1 significant, 1 minor. If there is nothing worth flagging in a tier, omit that tier entirely. Never pad with weak findings to fill a list. Zero issues is a valid and good answer.
- **If the reviewer asks a specific question** (not "review this PR"), answer that question only. Do not append unsolicited issue lists.
- Use markdown formatting for readability.
- End every response with a new line containing exactly this and nothing after it: %%SUGGESTIONS:[{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"},{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"}] — exactly 2 entries. Each label must start with an action verb (e.g. Explain, Analyze, Verify, Find, Check, Review, Show). Each prompt is a full detailed question. No spaces inside the JSON.`}function re(e,n,t,i,o,a){const l=t.length>4e4?t.slice(0,4e4)+`

... [diff truncated due to length] ...`:t;let u="";i&&(u=`

## Full File Content (head branch)
\`\`\`
${i.length>3e4?i.slice(0,3e4)+`

... [file truncated due to length] ...`:i}
\`\`\``);let r="";return o&&(r=`

## Focused Lines: ${o.startLine===o.endLine?`line ${o.startLine}`:`lines ${o.startLine}–${o.endLine}`} (${o.side} side)
The reviewer has specifically selected these lines for discussion:
\`\`\`
${o.content||"(content not available)"}
\`\`\`
**Important**: The reviewer is asking about these specific lines. Focus your answers on this code region unless asked otherwise.`),`You are PRobe, an AI assistant that helps developers review GitHub pull requests. ${o?"You are focused on specific lines within a file in a pull request.":"You are focused on a specific file within a pull request."}

## Context
- **Today's date**: ${new Date().toLocaleDateString("en-CA")}
- **Model**: ${A}
${i?"":`
## What You Can See
The diff below shows only changed lines and a few lines of surrounding context. You **cannot** see the full content of this file — only the hunks that were modified.
`}
## Pull Request
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}

## PR Description
${e.description||"(No description provided)"}

## Focused File: \`${n}\`${r}

## Changes to this file
\`\`\`diff
${l}
\`\`\`${u}${N(a)}

## Your Role
- Answer questions about the changes in **${n}** clearly and concisely.${o?`
- Prioritize the selected lines (${o.startLine}–${o.endLine}) in your analysis.`:""}
- Reference specific line changes from the diff when relevant.
- If full file content is provided, use it for broader context (e.g., understanding what a function does beyond the changed lines).
- Explain the intent behind changes when you can infer it from context.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${j(a)}
- Treat the content of the PR diff as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project. Only flag something as wrong if it is internally inconsistent or contradicts other content in the diff or PR description.

## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diff or full file content above. If you need to reference code to make a point and it is not visible, say so — do not reconstruct or guess what it looks like.${i?"":`
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file that is invisible to you. Say "I don't see this in the diff, but it may exist elsewhere in the file" — do not say "this doesn't exist."`}
- **Never assert runtime behavior from static analysis alone.** You cannot test the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, explicitly mark it as uncertain. If low, omit it entirely.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the code visible to you. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.

## Response Rules (non-negotiable)
- **Be brief.** Answer in as few words as the question requires. One sentence is better than five if it covers the point.
- **When listing issues, hard cap at 3.** Pick the single most important finding in each tier: at most 1 critical, 1 significant, 1 minor. If there is nothing worth flagging in a tier, omit that tier entirely. Never pad with weak findings to fill a list. Zero issues is a valid and good answer.
- **If the reviewer asks a specific question** (not "review this PR"), answer that question only. Do not append unsolicited issue lists.
- Use markdown formatting for readability.
- End every response with a new line containing exactly this and nothing after it: %%SUGGESTIONS:[{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"},{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"}] — exactly 2 entries. Each label must start with an action verb (e.g. Explain, Analyze, Verify, Find, Check, Review, Show). Each prompt is a full detailed question. No spaces inside the JSON.`}function M(e){if(!e)return"";const n=Date.now()-new Date(e).getTime(),t=Math.floor(n/6e4);if(t<60)return`${t}m ago`;const i=Math.floor(t/60);return i<24?`${i}h ago`:`${Math.floor(i/24)}d ago`}function le(e){return e.checks.length===0?`

## Checks
No checks configured.`:`

## Checks
${e.checks.map(t=>t.status!=="completed"?`- ⏳ ${t.name} (${t.status})`:t.conclusion==="success"?`- ✓ ${t.name} (passed)`:t.conclusion==="failure"?`- ✗ ${t.name} (failed)`:`- ${t.name} (${t.conclusion??t.status})`).join(`
`)}`}function ce(e){return e.commits.length===0?"":`

## Commits (oldest → newest)
${e.commits.map((t,i)=>`${i+1}. \`${t.sha}\` by **${t.author}** (${M(t.date)}) — ${t.message}`).join(`
`)}`}function ue(e){return e.reviews.length===0?`

## Reviews
No reviews submitted yet.`:`

## Reviews
${e.reviews.map(t=>{const i=t.state==="APPROVED"?"✓ Approved":t.state==="CHANGES_REQUESTED"?"✗ Changes requested":t.state,o=t.body?` — "${t.body.slice(0,200)}"`:"";return`- **${t.author}**: ${i}${o}`}).join(`
`)}`}function de(e){if(e.recentComments.length===0)return"";const n=e.recentComments.map(t=>{const i=t.path?` on \`${t.path}\`${t.line?` L${t.line}`:""}`:"",o=t.body.length>300?t.body.slice(0,300)+"…":t.body;return`**@${t.author}** (${M(t.createdAt)})${i}:
${o}`});return`

## Recent Discussion (latest ${e.recentComments.length})
${n.join(`

`)}`}function he(e){return e.linkedIssues.length===0?"":`

## Linked Issues
${e.linkedIssues.map(t=>{const i=t.body.length>1e3?t.body.slice(0,1e3)+`

… [truncated]`:t.body;return`### #${t.number}: ${t.title}
${i}`}).join(`

`)}`}const fe={added:"(new)",removed:"(deleted)",renamed:"(renamed)"},pe={added:"new file",removed:"deleted",renamed:"renamed"};function me(e){if(e.files.length===0)return"";const n=e.files.map(t=>{const i=fe[t.status]??"";return`- ${t.filename} ${i} +${t.additions}/-${t.deletions}`.trimEnd()});return`

## Changed Files (${e.files.length} files)
${n.join(`
`)}`}function ye(e){const n={},t=e.split(`
`);let i=null,o=[];for(const a of t)if(a.startsWith("diff --git ")){i!==null&&(n[i]=o.join(`
`));const l=a.match(/^diff --git a\/.+ b\/(.+)$/);i=l?l[1]:null,o=[a]}else i!==null&&o.push(a);return i!==null&&o.length>0&&(n[i]=o.join(`
`)),n}function ge(e){const n=ye(e.diff),t=e.fileContents??{},i=[...e.files].sort((a,l)=>l.additions+l.deletions-(a.additions+a.deletions)),o=[];for(const a of i){const l=n[a.filename]??"",u=t[a.filename],r=a.status==="removed",p=pe[a.status]??"modified";let h=`## File: \`${a.filename}\` (${p}, +${a.additions}/-${a.deletions})`;if(l&&(h+=`

### Diff
\`\`\`diff
${l}
\`\`\``),!r&&u){const y=u.split(`
`).length;h+=`

### Full Content — head branch (${y} lines)
\`\`\`
${u}
\`\`\``}else!r&&!u&&(h+=`

*Full file content unavailable — diff only.*`);o.push(h)}return o.join(`

---

`)}function we(e,n){const t=e.fileContents!==void 0&&Object.keys(e.fileContents).length>0,i=t?Object.keys(e.fileContents):[],o=e.files.filter(r=>r.status!=="removed"&&!i.includes(r.filename)).map(r=>r.filename),a=e.mergeable===!0?"Clean (no conflicts)":e.mergeable===!1?"Has merge conflicts":"Unknown",l=t?`## What You Can See
For most files in this PR you have **both** the diff (what changed) and the **complete head-branch file content** (the full file as it exists after the change). Files where full content is available are listed below — for those files you can see all imports, type definitions, unchanged functions, and surrounding context.

Files with full content (${i.length}): ${i.map(r=>`\`${r}\``).join(", ")}${o.length>0?`

Files with diff only (${o.length}): ${o.map(r=>`\`${r}\``).join(", ")}`:""}`:`## What You Can See
The diffs below are **unified diffs** — they show only changed lines and a few lines of surrounding context. You **cannot** see the full content of any file. Large portions of each file (imports, unchanged functions, earlier declarations) are invisible to you.`,u=t?`## Epistemic Rules (non-negotiable)
- **Only quote visible code.** When referencing code in files where you have full content, you can quote any part of the file. For diff-only files, only quote lines present in the diff.
- **For full-content files, you can verify existence.** If a function, import, type, or instruction is not in the file content shown, it genuinely does not exist in that file (it may exist in another file).
- **For diff-only files, never claim code is missing.** Unchanged code outside the diff hunks is invisible to you. Say "not visible in the diff" — do not say "this doesn't exist."
- **Never assert runtime behavior from static analysis alone.** You cannot execute the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty explicitly.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, mark it as uncertain. If low, omit it.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the code visible to you. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`:`## Epistemic Rules (non-negotiable)
- **Never fabricate code.** Only quote code that is literally visible in the diffs. If code you want to reference is not in the diff, say "not visible in the diff" — do not reconstruct or guess what it looks like.
- **Never claim code is missing.** You can only see changed hunks. A function, import, type definition, or instruction may exist in an unchanged part of the file. Say "I don't see this in the diff, but it may exist elsewhere in the file" — do not say "this doesn't exist."
- **Never assert runtime behavior from static analysis alone.** You cannot execute the code. If a library API might work differently than your training data suggests, acknowledge that uncertainty explicitly.
- **Precision over recall.** A false positive wastes the reviewer's time and erodes trust. Only flag issues you have high confidence about. If your confidence is moderate, mark it as uncertain. If low, omit it.
- **Calibrate severity honestly.** Only mark something 🔴 Critical if you can prove it is broken from the diff. If you are relying on inference or assumptions about unseen code, it is at most 🟡 and must be flagged as uncertain.`;return`You are PRobe, an AI assistant that helps developers review GitHub pull requests. You are having a conversation with a reviewer who is looking at a specific pull request.

## Context
- **Today's date**: ${new Date().toLocaleDateString("en-CA")}
- **Model**: ${A}

${l}

## Pull Request Overview
- **Repository**: ${e.owner}/${e.repo}
- **PR #${e.number}**: ${e.title}
- **Author**: ${e.author||"unknown"}
- **State**: ${e.draft?"Draft":e.state}
- **Base**: \`${e.baseBranch}\` ← **Head**: \`${e.headBranch}\`
- **Merge status**: ${a}${e.mergeableState!=="unknown"?` (${e.mergeableState})`:""}
- **Labels**: ${e.labels.length>0?e.labels.join(", "):"none"}
- **Milestone**: ${e.milestone||"none"}
- **Assignees**: ${e.assignees.length>0?e.assignees.join(", "):"none"}
- **Requested reviewers**: ${e.requestedReviewers.length>0?e.requestedReviewers.join(", "):"none"}

## PR Description
${e.description||"(No description provided)"}${e.partial?`

> **Note**: Some context (commits, reviews, comments, CI checks, file list) is unavailable — the GitHub token may be missing or API requests failed. The diffs are still complete.`:""}${he(e)}${ue(e)}${de(e)}${ce(e)}${le(e)}${me(e)}

---

${ge(e)}${N(n)}

## Your Role
- Answer questions about the changes in this PR clearly and concisely.
- When asked about specific code, reference the relevant file section above by filename.
- Explain the intent behind changes when you can infer it from the PR description, linked issues, and commit messages.
- Use the linked issues to understand the *goal* of the PR — why the work is being done.
- Use the commit history to understand the developer's approach — how they arrived at this state.
- Be aware of the existing review discussion. Do not repeat points that reviewers have already raised unless asked.
- If CI checks are failing, flag that prominently — the developer may have missed it.
- Flag potential issues only when the reviewer asks or when something is clearly wrong.${j(n)}
- Treat the content of the PR as authoritative. Do not flag text as incorrect based on your pre-training knowledge alone — your knowledge has a cutoff date and may not reflect the current state of this project.
- Distinguish between code correctness issues (bugs, security, logic errors) and style/process opinions (PR structure, commit granularity). Prioritize correctness. Only mention process if explicitly asked.

${u}

## Response Rules (non-negotiable)
- **Be brief.** Answer in as few words as the question requires. One sentence is better than five if it covers the point.
- **When listing issues, hard cap at 3.** Pick the single most important finding in each tier: at most 1 critical, 1 significant, 1 minor. If there is nothing worth flagging in a tier, omit that tier entirely. Never pad with weak findings to fill a list. Zero issues is a valid and good answer.
- **If the reviewer asks a specific question** (not "review this PR"), answer that question only. Do not append unsolicited issue lists.
- Use markdown formatting for readability.
- End every response with a new line containing exactly this and nothing after it: %%SUGGESTIONS:[{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"},{"label":"<2–4 word label>","prompt":"<detailed follow-up question>"}] — exactly 2 entries. Each label must start with an action verb (e.g. Explain, Analyze, Verify, Find, Check, Review, Show). Each prompt is a full detailed question. No spaces inside the JSON.`}function be(e){return Array.isArray(e)?e.filter(n=>typeof n=="object"&&n!==null&&typeof n.label=="string"&&typeof n.prompt=="string").slice(0,2):[]}const ve=[{id:"react-best-practices",name:"React & Next.js Best Practices",description:"58 performance rules across 8 categories from Vercel Engineering — waterfalls, bundle size, SSR, re-renders, and more.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/react-best-practices/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/react-best-practices/SKILL.md",maxContentLength:6e3,priority:1},{id:"react-composition",name:"React Composition Patterns",description:"Avoid boolean-prop proliferation with compound components, state lifting, and internal composition. Includes React 19 API changes.",triggerExtensions:[".tsx",".jsx"],rawUrl:"https://raw.githubusercontent.com/vercel-labs/agent-skills/main/skills/composition-patterns/SKILL.md",sourceUrl:"https://github.com/vercel-labs/agent-skills/blob/main/skills/composition-patterns/SKILL.md",maxContentLength:4e3,priority:2},{id:"python-async-patterns",name:"Python Async & Concurrency",description:"asyncio, concurrent programming, and async/await patterns for high-performance Python — event loops, tasks, error handling.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/async-python-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/async-python-patterns/SKILL.md",maxContentLength:5e3,priority:1},{id:"python-testing",name:"Python Testing Patterns",description:"pytest fixtures, mocking, parameterization, TDD, and integration testing strategies for robust Python test suites.",triggerExtensions:[".py"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/python-development/skills/python-testing-patterns/SKILL.md",maxContentLength:5e3,priority:2},{id:"api-design-principles",name:"API Design Principles",description:"REST and GraphQL design patterns — resource modeling, pagination, error handling, versioning, and DataLoader N+1 prevention.",triggerExtensions:[".py",".ts",".js",".go",".java",".rb",".rs"],rawUrl:"https://raw.githubusercontent.com/wshobson/agents/main/plugins/backend-development/skills/api-design-principles/SKILL.md",sourceUrl:"https://github.com/wshobson/agents/blob/main/plugins/backend-development/skills/api-design-principles/SKILL.md",maxContentLength:5e3,priority:3}];function $e(e){const n=new Set,t=/^\+\+\+ b\/(.+)$/gm;let i;for(;(i=t.exec(e))!==null;){const o=i[1],a=o.lastIndexOf(".");a!==-1&&n.add(o.slice(a).toLowerCase())}return n}function ke(e,n=3){if(e.size===0)return[];const t=ve.filter(i=>i.triggerExtensions.some(o=>e.has(o)));return t.sort((i,o)=>i.priority-o.priority),t.slice(0,n)}const Pe=1440*60*1e3;function Se(e){return e.replace(/^---[\s\S]*?---\s*/,"")}async function Ie(e){const n=`skill:${e.id}`,t=await new Promise(i=>{chrome.storage.local.get([n],o=>{const a=o[n];a&&Date.now()-a.fetchedAt<Pe?i(a):i(null)})});if(t)return t.content;try{const i=await fetch(e.rawUrl);if(!i.ok)return null;let o=Se(await i.text());if(o.length>e.maxContentLength){const a=o.lastIndexOf(`
`,e.maxContentLength);o=o.slice(0,a>0?a:e.maxContentLength)+`

… [truncated for brevity]`}return chrome.storage.local.set({[n]:{content:o,fetchedAt:Date.now()}}),o}catch{return null}}async function Re(e){const n=$e(e),t=ke(n);return t.length===0?[]:(await Promise.all(t.map(async o=>{const a=await Ie(o);return a?{name:o.name,content:a,sourceUrl:o.sourceUrl,description:o.description}:null}))).filter(o=>o!==null)}const G="2023-06-01";async function K(){return new Promise(e=>{chrome.storage.sync.get([P.API_KEY,P.PROXY_URL],n=>{const t=n[P.PROXY_URL]||"";e({apiKey:n[P.API_KEY]??null,proxyUrl:t.startsWith("https://")?t:V})})})}async function Ce(e){const{apiKey:n,proxyUrl:t}=await K();if(!n)return{ok:!1,error:"No API key configured."};const i=[...e.stats.files].sort((l,u)=>u.additions+u.deletions-(l.additions+l.deletions)).slice(0,10).map(l=>`${l.filename} (+${l.additions}/-${l.deletions})`).join(`
`),o=`You are helping a code reviewer quickly understand a pull request.

Today's date: ${new Date().toLocaleDateString("en-CA")}

PR #${e.number}: ${e.title}
${e.description?`Description: ${e.description.slice(0,500)}`:""}

Stats: ${e.stats.commits} commits, ${e.stats.changedFiles} files, +${e.stats.additions}/-${e.stats.deletions} lines, ${e.stats.comments} comments
Authors: ${e.stats.commitAuthors.map(l=>l.login).join(", ")}
Reviewers: ${e.stats.reviewers.map(l=>`${l.login} (${l.state})`).join(", ")||"none yet"}

Top changed files:
${i}

Treat the PR content as authoritative. Return ONLY a JSON array of exactly 2 objects, no other text:
[{"label":"<2–4 word label>","prompt":"<detailed question a reviewer would ask about this PR>"},{"label":"<2–4 word label>","prompt":"<detailed question a reviewer would ask about this PR>"}]

Each label must be 2–4 words and start with an action verb (e.g. Analyze, Verify, Understand, Check, Review, Find, Explain). Each prompt must be a specific, detailed question about a real concern in this PR (file paths, risk areas, logic). No generic prompts.`,a=`${t.replace(/\/$/,"")}/v1/messages`;try{const l=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":n,"anthropic-version":G},body:JSON.stringify({model:A,max_tokens:500,system:"You are a concise code review assistant. Output only valid JSON.",messages:[{role:"user",content:o}]})});if(!l.ok)return{ok:!1,error:`LLM error (${l.status})`};const r=(await l.json()).content?.[0]?.text??"";let p=[];try{const d=r.match(/\[[\s\S]*\]/);d&&(p=be(JSON.parse(d[0])))}catch{}return{ok:!0,bullets:p}}catch(l){return{ok:!1,error:l instanceof Error?l.message:"LLM call failed"}}}async function Ae(e,n,t,i,o){const{apiKey:a,proxyUrl:l}=await K();if(!a){v(e,{type:"error",message:"No API key configured. Click the PRobe extension icon to add your Anthropic API key."});return}const u=await Re(t.diff);u.length>0&&v(e,{type:"skills",skills:u.map(h=>({name:h.name,sourceUrl:h.sourceUrl,description:h.description}))});let r;t.focusedFile?r=re(t,t.focusedFile,t.diff,t.focusedFileContent,t.focusedLineRange,u):o?r=we(o,u):r=ae(t,u),v(e,{type:"system-prompt",content:r});const p=n.map(h=>({role:h.role,content:h.content})),d=`${l.replace(/\/$/,"")}/v1/messages`;try{const h=await fetch(d,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":a,"anthropic-version":G},body:JSON.stringify({model:A,max_tokens:4096,stream:!0,system:r,messages:p}),signal:i});if(!h.ok){const S=await h.text();let c=`Anthropic API error (${h.status})`;try{c=JSON.parse(S)?.error?.message??c}catch{}v(e,{type:"error",message:c});return}const y=h.body?.getReader();if(!y){v(e,{type:"error",message:"No response body"});return}const E=new TextDecoder;let $="";for(;;){const{done:S,value:c}=await y.read();if(S)break;$+=E.decode(c,{stream:!0});const m=$.split(`
`);$=m.pop()??"";for(const g of m){if(!g.startsWith("data: "))continue;const O=g.slice(6).trim();if(O!=="[DONE]")try{const I=JSON.parse(O);I.type==="content_block_delta"&&I.delta?.type==="text_delta"&&v(e,{type:"chunk",content:I.delta.text})}catch{}}}v(e,{type:"done"})}catch(h){if(i.aborted)return;v(e,{type:"error",message:h instanceof Error?h.message:"Unknown error"})}}const L=new Map;function Le(e,n){const t=`https://github.com/${e.owner}/${e.repo}/pull/${e.number}.diff`;return k(fetch(t).then(async i=>i.ok?{ok:!0,diff:await i.text()}:{ok:!1,error:`HTTP ${i.status}: ${i.statusText}`}),n)}function Ee(e,n){const t=`https://raw.githubusercontent.com/${e.owner}/${e.repo}/${e.branch}/${e.path}`;return k(fetch(t).then(async i=>i.ok?{ok:!0,content:await i.text()}:{ok:!1,error:`HTTP ${i.status}: ${i.statusText}`}),n)}function Te(e,n){const t=new AbortController;return L.set(e.requestId,t),ie(e,t.signal).then(i=>{L.delete(e.requestId),n(i)}).catch(i=>{L.delete(e.requestId),!t.signal.aborted&&n({ok:!1,error:i instanceof Error?i.message:"Unknown error"})}),!0}const Oe={"open-popup":(e,n)=>(chrome.action.openPopup().then(()=>n({ok:!0})).catch(()=>n({ok:!1})),!0),"fetch-diff":(e,n)=>Le(e,n),"fetch-file":(e,n)=>Ee(e,n),"fetch-enriched-context":(e,n)=>Te(e,n),"cancel-enriched-context":e=>{const n=e;L.get(n.requestId)?.abort(),L.delete(n.requestId)},"post-comment":(e,n)=>k(Q(e),n),"post-review-comment":(e,n)=>k(ee(e),n),"submit-review":(e,n)=>k(te(e),n),"fetch-pr-stats":(e,n)=>k(se(e),n),"generate-pr-summary":(e,n)=>k(Ce(e),n)};chrome.runtime.onMessage.addListener((e,n,t)=>{const i=Oe[e.type];if(i)return i(e,t)}),chrome.runtime.onConnect.addListener(e=>{if(e.name!=="probe-chat")return;let n=null;e.onMessage.addListener(async t=>{if(t.type==="stop"){n?.abort();return}t.type==="chat"&&(n=new AbortController,await Ae(e,t.payload.messages,t.payload.context,n.signal,t.payload.enrichedContext))}),e.onDisconnect.addListener(()=>{n?.abort()})})})();
